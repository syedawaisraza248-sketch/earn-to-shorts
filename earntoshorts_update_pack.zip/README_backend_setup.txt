EarnToShorts update pack

Files:
- earntoshorts_updated_with_withdrawal_admin.html: updated frontend based on your uploaded HTML.
- firestore.rules: starter rules for a future Firebase integration.

The HTML adds a local withdrawal request list in the Admin Panel, Pending/Paid/Rejected status, user's own request status, and a direct YouTube link. It still stores data in localStorage: requests will NOT appear on a different device/browser and the client-side admin PIN is NOT secure. Do not use this local demo for real money.

To make it permanent and secure, configure Firebase Authentication + Firestore, add Firebase config to the page, publish firestore.rules, create an admins/{Firebase Auth UID} document in Firestore, and implement trusted server-side Cloud Functions for wallet balance deductions, reward validation, and atomic transactions. Never allow the browser to directly change its own wallet balance.

YouTube limitation: a static page cannot reliably verify a person watched 20 seconds after opening YouTube in a separate tab/app. Do not promise cash rewards based only on that timer; make sure incentives comply with YouTube policies.
