EarnToShorts — latest USD frontend update pack

Files:
- earntoshorts_usd_professional_updated.html — updated frontend based on the HTML you uploaded.
- firestore.rules — starter rules for a future Firebase integration; these rules are not connected to the HTML automatically.

Frontend updates included:
- First-login bonus of $1.00, once per email in this browser.
- $0.50 platform reward per eligible video slot/day (the 20-second timer is only a client-side timer and cannot verify real viewing in another tab).
- Daily Treasure $0.50 and Spin outcomes $0, $0, $0.50, $0.50.
- Dashboard shows Wallet Balance and Total Earned.
- Withdrawal minimum $30, maximum $300 per request and $300 monthly limit in the local demo.
- Withdrawal states: Pending → Approved → Paid; admin must enter a transaction reference before marking Paid.
- User can see request date, status and transaction reference.
- Mobile layout and navigation retained.
- Referral option is not added.

IMPORTANT LIMITATIONS:
This is still a static HTML/localStorage demo. Accounts, wallet, reward flags and withdrawal requests are stored only in the current browser and can be edited by a user. The admin PIN in the HTML is not secure authentication. The $1 first-login reward is only tracked locally, not globally across devices. Monthly withdrawal cap is also enforced only in this browser. Do not use it for real money until Firebase Authentication and a trusted server-side backend/Cloud Functions are implemented and tested.

YouTube watch limitation: a static page cannot reliably prove that someone watched 20 seconds after opening YouTube in another tab/app. Review YouTube policies before offering rewards for views or engagement.

Firebase next steps:
1. Enable Firebase Authentication (Google and/or email/password).
2. Create Firestore Database.
3. Configure the app with your Firebase web config and implement Firebase SDK integration.
4. Deploy firestore.rules only after testing them in the Firebase Rules Playground.
5. Create an admins/{Firebase Auth UID} document using a trusted admin process; rules prevent clients from creating admin records.
6. Implement Cloud Functions/server-side transactions for balance deductions, reward eligibility, monthly withdrawal caps, and status transitions. Never let the browser directly edit its own wallet balance.
